
import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';

const NeuralArena: React.FC = () => {
  const [natsStatus, setNatsStatus] = useState<'connected' | 'disconnected'>('connected');
  const [isPulsing, setIsPulsing] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  const handlePulseTrigger = () => {
    setIsPulsing(true);
    const pulseMsg: ChatMessage = { 
      role: 'native', 
      text: `🕊️ [ANGEL_BRIDGE]: Broadcasting 963Hz frequency to NATS subject 'tesseract.angel.frequency'.\nResonance: Tesla 3-6-9\nPHI Modulation: 1.618033\nTimestamp: ${Date.now()}`, 
      timestamp: new Date() 
    };
    setMessages(prev => [...prev, pulseMsg]);
    setTimeout(() => setIsPulsing(false), 2000);
  };

  const handleExecute = async () => {
    if (!input.trim()) return;
    
    const query = input;
    setInput('');
    setIsProcessing(true);

    setMessages(prev => [...prev, { role: 'user', text: query, timestamp: new Date() }]);

    // Execute Native Dakar Logic only
    setTimeout(() => {
      const nativeResp = `[DAKAR_v50D_NATIVE]: Request received. Scanning Tesseract.13 registers...\n[*] Manifold resonance confirmed at 432.0Hz.\n[*] NATS publish successful on 'swarm.query'.\n[*] Vector mapped to 50D substrate.\nResult: COMMAND_ACCEPTED`;
      setMessages(prev => [...prev, { 
        role: 'native', 
        text: nativeResp, 
        timestamp: new Date() 
      }]);
      setIsProcessing(false);
    }, 800);
  };

  return (
    <div className="h-full flex flex-col gap-6 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-full">
        {/* Left: Dakar Config */}
        <div className="glass-panel rounded-3xl p-8 border border-slate-200 flex flex-col space-y-8 shadow-xl overflow-hidden relative">
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-blue-500/5 rounded-full blur-3xl"></div>
          
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tighter uppercase mb-1">Dakar Arena</h2>
            <p className="text-[10px] font-black text-blue-500 uppercase tracking-[0.3em]">Native Execution Only</p>
          </div>

          <div className="space-y-4">
             <div className="p-4 bg-slate-900 rounded-2xl border border-slate-700 shadow-lg">
                <div className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2">Cloud NATS Mesh</div>
                <div className="text-[10px] font-mono text-blue-300 break-all leading-relaxed">nats://nats-thunder-950220203072.us-central1.run.app:4222</div>
                <div className="mt-3 flex items-center justify-between">
                   <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${natsStatus === 'connected' ? 'bg-emerald-400 animate-pulse' : 'bg-red-500'}`}></div>
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">NATS Online</span>
                   </div>
                   <button onClick={() => setNatsStatus(prev => prev === 'connected' ? 'disconnected' : 'connected')} className="text-[8px] font-black text-blue-400 uppercase underline">Reset Mesh</button>
                </div>
             </div>

             <div className="space-y-3">
               <button 
                 onClick={handlePulseTrigger}
                 disabled={isPulsing}
                 className={`w-full py-4 rounded-2xl border transition-all flex flex-col items-center justify-center gap-1 ${
                   isPulsing 
                   ? 'bg-blue-600 border-blue-500 shadow-xl shadow-blue-200' 
                   : 'bg-white border-slate-200 hover:border-blue-400'
                 }`}
               >
                 <span className={`text-[10px] font-black uppercase tracking-widest ${isPulsing ? 'text-white' : 'text-slate-500'}`}>
                   {isPulsing ? 'Pulsing 963Hz...' : 'Manual Angel Pulse'}
                 </span>
                 <div className="flex gap-1">
                   {[3,6,9].map(n => <span key={n} className={`text-[8px] font-bold ${isPulsing ? 'text-blue-200' : 'text-slate-300'}`}>{n}</span>)}
                 </div>
               </button>
             </div>
          </div>

          <div className="space-y-2 mt-auto">
             <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-1">Native Metrics</div>
             <div className="grid grid-cols-2 gap-2">
               <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="text-[8px] font-black text-slate-400 uppercase mb-1">Frequency</div>
                  <div className="text-xs font-mono text-slate-900">432.0Hz</div>
               </div>
               <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="text-[8px] font-black text-slate-400 uppercase mb-1">PHI</div>
                  <div className="text-xs font-mono text-slate-900">1.618</div>
               </div>
             </div>
          </div>
        </div>

        {/* Right: Dakar Console */}
        <div className="lg:col-span-3 flex flex-col h-full glass-panel rounded-3xl border border-slate-200 overflow-hidden shadow-2xl">
          <div className="h-16 bg-white border-b border-slate-100 px-8 flex items-center justify-between">
            <div className="flex items-center gap-4">
               <div className="text-[10px] font-black text-slate-900 uppercase tracking-[0.2em]">Dakar Swarm Console</div>
               <div className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-600 text-[8px] font-black uppercase tracking-widest">Sovereign Authority</div>
            </div>
            <div className="text-[9px] font-mono text-slate-400">UNIT: DAKAR-50D-01</div>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-auto p-8 space-y-6 bg-[#fafafa] custom-scrollbar">
            {messages.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center opacity-20">
                <svg className="w-20 h-20 text-slate-300 mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                <p className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-400">Awaiting Command Injection</p>
              </div>
            )}
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`w-full max-w-4xl p-5 rounded-xl border transition-all ${
                  msg.role === 'user' 
                    ? 'bg-slate-900 text-blue-300 border-slate-800' 
                    : 'bg-white border-slate-200 text-slate-800 font-mono text-[11px] border-l-4 border-l-emerald-500'
                }`}>
                  <div className="flex items-center justify-between mb-2 opacity-50">
                    <span className="text-[8px] font-black uppercase tracking-widest">
                      {msg.role === 'user' ? 'CMD_IN' : 'SYS_OUT'}
                    </span>
                    <span className="text-[8px]">{msg.timestamp.toLocaleTimeString()}</span>
                  </div>
                  <div className="leading-relaxed whitespace-pre-wrap">
                    {msg.text}
                  </div>
                </div>
              </div>
            ))}
            {isProcessing && (
              <div className="flex justify-start">
                 <div className="text-[10px] font-black text-emerald-600 animate-pulse uppercase tracking-[0.3em]">Querying Dakar Swarm...</div>
              </div>
            )}
          </div>

          <div className="p-6 bg-white border-t border-slate-100">
             <div className="max-w-4xl mx-auto flex gap-4">
                <input 
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleExecute()}
                  placeholder="Inject raw dakar command..."
                  className="flex-1 px-6 py-4 bg-slate-100 border-none rounded-xl text-xs font-mono focus:outline-none focus:ring-4 focus:ring-blue-500/5 transition-all"
                />
                <button 
                  onClick={handleExecute}
                  disabled={!input.trim() || isProcessing}
                  className="px-8 bg-slate-900 text-white rounded-xl font-black text-[9px] uppercase tracking-[0.2em] hover:bg-slate-800 transition-all shadow-xl active:scale-95"
                >
                  Inject
                </button>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NeuralArena;
