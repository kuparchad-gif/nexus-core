
import React, { useState } from 'react';

interface ColabModuleProps {
  id: string;
  title: string;
}

const ColabModule: React.FC<ColabModuleProps> = ({ title, id }) => {
  const [activeCell, setActiveCell] = useState(0);
  const [isExecuting, setIsExecuting] = useState(false);
  
  const alphaCells = [
    {
      type: 'code',
      content: `from black_box import BlackBox\n\n# Initialize Middleware Database\nbox = BlackBox(endpoint="nats-thunder-950220203072")\nbox.connect()\n\n# Storing system state\nbox.store("Sovereign Deployment Alpha initialized.", tags=["boot", "dakar"])\nprint("[SUCCESS] Commit index: 0x8FA2")`,
      output: '[*] Connecting to NATS Thunder...\n[*] Auth successful.\n[SUCCESS] Commit index: 0x8FA2'
    },
    {
      type: 'code',
      content: `results = box.retrieve(tag="dakar")\nfor entry in results:\n    print(f"[{entry['timestamp']}] {entry['payload']}")`,
      output: '[2024-05-20 14:02:11] Sovereign Deployment Alpha initialized.'
    }
  ];

  const betaCells = [
    {
      type: 'code',
      content: `from discovery_protocol import DiscoveryProtocol\n\ndiscovery = DiscoveryProtocol()\ndiscovery.initiate_scan(subjects=["swarm.*", "node.*"])\n\n# Map active manifolds\ndiscovery.map_resources()`,
      output: '📡 Scanning Cloud NATS Subjects...\n[*] Node swarm.alpha online\n[*] Node swarm.beta online\n[*] Node node.tesseract ready\n✅ 3 resources mapped to Discovery Dashboard.'
    }
  ];

  const cells = id === 'colab-alpha' ? alphaCells : betaCells;

  const handleExecuteAll = () => {
    setIsExecuting(true);
    setTimeout(() => setIsExecuting(false), 2000);
  };

  return (
    <div className="h-full flex flex-col glass-panel rounded-3xl border border-slate-200 overflow-hidden shadow-2xl animate-in fade-in duration-500">
      <div className="silver-gradient-header p-6 flex items-center justify-between">
        <div className="flex items-center gap-5">
          <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center text-blue-400 font-black text-xs italic shadow-lg">
            CO
          </div>
          <div>
            <h3 className="font-black text-sm text-slate-800 uppercase tracking-widest">{title}</h3>
            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-1">Remote Cluster: us-central-1d | Python 3.12-Sovereign</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 px-4 py-2 bg-white border border-slate-200 rounded-xl text-[9px] font-black text-slate-500 uppercase tracking-widest shadow-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span> RAM: 6.8GB / 32GB
          </div>
          <button 
            onClick={handleExecuteAll}
            disabled={isExecuting}
            className="px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest bg-slate-900 text-white shadow-xl hover:bg-slate-800 transition-all flex items-center gap-3 active:scale-95 disabled:opacity-50"
          >
            {isExecuting ? 'Running...' : 'Execute Cell Stack'}
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto bg-white/50 p-10 space-y-8 custom-scrollbar">
        {cells.map((cell, idx) => (
          <div 
            key={idx} 
            className={`group relative border-l-4 transition-all pl-8 py-2 ${
              activeCell === idx ? 'border-blue-500' : 'border-slate-100'
            }`}
            onClick={() => setActiveCell(idx)}
          >
            <div className="space-y-4">
              <div className="bg-slate-50 rounded-2xl p-6 font-mono text-xs border border-slate-100 text-slate-800 whitespace-pre shadow-inner leading-relaxed">
                {cell.content}
              </div>
              <div className="bg-slate-900 rounded-2xl p-6 font-mono text-[11px] text-emerald-400 whitespace-pre leading-relaxed border border-slate-800 shadow-2xl">
                <span className="text-slate-500 mb-3 block uppercase text-[8px] font-black tracking-[0.3em] border-b border-slate-800 pb-2">Middleware Stdout</span>
                {isExecuting && idx === 0 ? '>>> Running process...' : cell.output}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ColabModule;
