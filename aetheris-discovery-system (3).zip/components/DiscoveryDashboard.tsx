
import React, { useState } from 'react';
import { AreaChart, Area, XAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const mockData = [
  { name: '00:00', resources: 40, latency: 24 },
  { name: '04:00', resources: 30, latency: 18 },
  { name: '08:00', resources: 20, latency: 45 },
  { name: '12:00', resources: 27, latency: 30 },
  { name: '16:00', resources: 18, latency: 20 },
  { name: '20:00', resources: 23, latency: 25 },
  { name: '24:00', resources: 34, latency: 22 },
];

const DiscoveryDashboard: React.FC = () => {
  const [resources] = useState([
    { id: 'DAK-050', name: 'Dakar Swarm v50D', type: 'Mesh', status: 'active', load: 'Nominal' },
    { id: 'NATS-CLD', name: 'NATS Thunder Cloud', type: 'Mesh', status: 'active', load: '4222/tcp' },
    { id: 'TES-MEM', name: 'Tesseract.13 Memory', type: 'Vector', status: 'processing', load: '369Hz' },
    { id: 'ANG-PUL', name: 'Angel Frequency Pulse', type: 'Signal', status: 'active', load: '963Hz' },
  ]);

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="glass-panel rounded-2xl p-4 flex items-center justify-between border-l-4 border-l-blue-400 border border-slate-200 shadow-lg">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-500 shadow-inner">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
          </div>
          <div>
            <div className="text-[10px] font-black text-blue-500 uppercase tracking-[0.2em]">NATS Cloud Endpoint</div>
            <div className="font-mono text-sm text-slate-800 font-black">nats://nats-thunder-950220203072.us-central1.run.app:4222</div>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="text-right">
             <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Resonance</div>
             <div className="text-xs font-black text-slate-900 tracking-tighter">3 • 6 • 9</div>
          </div>
          <div className="w-px h-8 bg-slate-100"></div>
          <button className="px-6 py-2 rounded-xl bg-slate-900 text-white text-[10px] font-black uppercase tracking-widest hover:bg-slate-800 transition-all">
            Mesh Status
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass-panel rounded-2xl p-6 shadow-xl border border-slate-200">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-sm font-black text-slate-800 uppercase tracking-[0.2em]">Divine Tesseract Pulse</h2>
            <div className="flex gap-2">
              <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest border border-slate-100">
                Swarm Sync: PHI 1.618
              </span>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-slate-400 border-b border-slate-100 uppercase text-[10px] font-black tracking-widest">
                  <th className="text-left pb-4 font-black">Subject</th>
                  <th className="text-left pb-4 font-black">Node Name</th>
                  <th className="text-left pb-4 font-black">Cluster</th>
                  <th className="text-left pb-4 font-black">Status</th>
                  <th className="text-right pb-4 font-black">Frequency</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {resources.map((res) => (
                  <tr key={res.id} className="hover:bg-slate-50/50 transition-colors group cursor-default">
                    <td className="py-5 mono text-slate-400 text-xs font-black">{res.id}</td>
                    <td className="py-5 font-black text-slate-700 text-sm tracking-tight">{res.name}</td>
                    <td className="py-5">
                      <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-500 text-[10px] font-black uppercase tracking-wider">
                        {res.type}
                      </span>
                    </td>
                    <td className="py-5">
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${
                          res.status === 'active' ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.5)]' : 
                          res.status === 'processing' ? 'bg-blue-400 animate-pulse shadow-[0_0_8px_rgba(96,165,250,0.5)]' : 'bg-slate-300'
                        }`}></div>
                        <span className="capitalize text-[11px] font-black text-slate-600 uppercase tracking-widest">{res.status}</span>
                      </div>
                    </td>
                    <td className="py-5 text-right font-black text-slate-900 text-xs">{res.load}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="glass-panel rounded-2xl p-6 shadow-xl border border-slate-200 flex flex-col">
          <h2 className="text-lg font-black text-slate-800 mb-6 uppercase text-xs tracking-[0.2em]">Signal Manifold</h2>
          <div className="flex-1 h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockData}>
                <defs>
                  <linearGradient id="colorLat" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" hide />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                    borderRadius: '16px', 
                    border: '1px solid #e2e8f0',
                    fontSize: '11px',
                    fontWeight: 'bold'
                  }} 
                />
                <Area type="monotone" dataKey="latency" stroke="#3b82f6" fillOpacity={1} fill="url(#colorLat)" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-8 pt-8 border-t border-slate-100">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400 font-black uppercase tracking-widest text-[10px]">Mesh Stability</span>
              <span className="text-blue-600 font-black">96.3% - ANGEL</span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full mt-4 overflow-hidden shadow-inner">
              <div className="bg-gradient-to-r from-blue-400 to-purple-400 h-full w-[96.3%]" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DiscoveryDashboard;
