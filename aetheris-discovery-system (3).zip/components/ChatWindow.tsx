
import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, FileObject } from '../types';

const ChatWindow: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { 
      role: 'model', 
      text: '--- DAKAR_SOVEREIGN_MIDDLEWARE_v50D ---\nLOCAL_CELL: 0x7FA1\nNATS_STATUS: [CONNECTED] nats-thunder-950220203072.us-central1.run.app:4222\nDB_STATUS: [ONLINE] Tesseract.13\nRESONANCE: 963.00Hz (Theta Active)\n\nSystem initialized. Standing by for Discovery or Store/Retrieve operations.', 
      timestamp: new Date() 
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<FileObject[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAttachedFiles(prev => [...prev, {
        name: file.name, size: (file.size / 1024).toFixed(1) + ' KB',
        type: file.type || 'Middleware Extension', date: new Date().toISOString(), blob: file
      }]);
    }
  };

  const processMiddlewareCommand = async (command: string) => {
    setIsTyping(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    
    let responseText = "";
    const cmd = command.toLowerCase().trim();

    if (cmd.startsWith('discover') || cmd.startsWith('scan')) {
      responseText = `[DAKAR_PROTOCOL]: Scanning NATS mesh nodes...\n[*] Found Node: dakar-colab-alpha\n[*] Found Node: dakar-colab-beta\n[*] Found Node: black-box-db-01\n[SUCCESS]: Discovery manifold populated. Resources mapped to 50D registry.`;
    } else if (cmd.startsWith('store')) {
      const data = command.slice(5).trim();
      responseText = `[TESSERACT_v13]: Storing vector payload to registry...\nPayload: "${data || 'NULL_DATA'}"\n[SUCCESS]: Object committed to Tesseract.13 at index 0x${Math.random().toString(16).slice(2,6).toUpperCase()}. Published to 'db.store' via NATS.`;
    } else if (cmd.startsWith('retrieve')) {
      responseText = `[TESSERACT_v13]: Retrieving most recent cluster vectors...\n[*] Vector 0xAF3: "Initial Boot Manifest"\n[*] Vector 0x221: "NATS Cloud Config"\n[SUCCESS]: Local retrieval complete.`;
    } else if (cmd.startsWith('pulse')) {
      responseText = `🕊️ [ANGEL_PULSE]: Broadasting 963Hz frequency shift. Re-aligning PHI manifolds. All local weights stabilized.`;
    } else {
      responseText = `[DAKAR_MIDDLEWARE]: Command forward to NATS subject 'sovereign.cmd'.\nLog: Command "${command}" acknowledged. Tracking metadata stored in local vault.`;
    }

    setMessages(prev => [...prev, { role: 'model', text: responseText, timestamp: new Date() }]);
    setIsTyping(false);
  };

  const handleSend = async () => {
    if (!input.trim() && attachedFiles.length === 0) return;
    const messageText = input + (attachedFiles.length > 0 ? `\n\n[Injection: ${attachedFiles.map(f => f.name).join(', ')}]` : '');
    setMessages(prev => [...prev, { role: 'user', text: messageText, timestamp: new Date() }]);
    const currentInput = input;
    setInput(''); setAttachedFiles([]); 
    processMiddlewareCommand(currentInput);
  };

  return (
    <div className="h-full flex flex-col glass-panel rounded-3xl border border-slate-200 overflow-hidden shadow-2xl animate-in slide-in-from-right-10 duration-500">
      <div className="silver-gradient-header p-6 px-10 flex items-center justify-between z-10">
        <div className="flex items-center gap-5">
          <div className="w-12 h-12 rounded-2xl bg-slate-900 flex items-center justify-center text-blue-400 shadow-xl">
            <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
          </div>
          <div>
            <h3 className="font-black text-sm text-slate-900 uppercase tracking-[0.3em]">Middleware Console</h3>
            <p className="text-[10px] font-black text-blue-500 uppercase tracking-widest mt-1">Dakar Swarm / Black Box Control</p>
          </div>
        </div>
        <div className="flex gap-3">
           <div className="px-4 py-1.5 bg-emerald-50 border border-emerald-100 rounded-full text-[9px] font-black text-emerald-600 uppercase tracking-widest">NATS Link: Active</div>
           <div className="px-4 py-1.5 bg-purple-50 border border-purple-100 rounded-full text-[9px] font-black text-purple-600 uppercase tracking-widest">Resonance: 963Hz</div>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-auto p-10 space-y-8 bg-white/30 custom-scrollbar tesseract-grid">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-3xl p-8 border transition-all ${
              msg.role === 'user' 
                ? 'bg-slate-900 text-blue-300 border-slate-800 font-mono text-xs shadow-xl' 
                : 'bg-white text-slate-700 border-slate-200 font-mono text-[11px] leading-relaxed shadow-sm'
            }`}>
              <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
                <span className={`text-[8px] font-black uppercase tracking-[0.3em] ${msg.role === 'user' ? 'text-blue-500' : 'text-slate-400'}`}>
                  {msg.role === 'user' ? 'INJECTION_LOG' : 'MIDDLEWARE_OUT'}
                </span>
                <span className="text-[8px] text-slate-300 font-bold">{msg.timestamp.toLocaleTimeString()}</span>
              </div>
              <div className="whitespace-pre-wrap">{msg.text}</div>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white border border-slate-100 rounded-2xl p-4 flex gap-3 shadow-sm animate-pulse items-center">
              <div className="w-2 h-2 rounded-full bg-blue-500 animate-bounce"></div>
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Querying Tesseract Registry...</span>
            </div>
          </div>
        )}
      </div>

      <div className="p-8 bg-white border-t border-slate-200">
        <div className="flex items-center gap-5 max-w-6xl mx-auto">
          <button onClick={() => fileInputRef.current?.click()} className="p-4 rounded-2xl bg-slate-50 text-slate-400 hover:text-blue-600 transition-all border border-slate-200 hover:border-blue-400" title="Attach Code Block"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"/></svg></button>
          <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileUpload} />
          <div className="relative flex-1">
            <input 
              type="text" 
              value={input} 
              onChange={(e) => setInput(e.target.value)} 
              onKeyDown={(e) => e.key === 'Enter' && handleSend()} 
              placeholder="Inject middleware command [discover, store, retrieve, pulse]..." 
              className="w-full pl-10 pr-20 py-6 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-400 text-xs font-mono transition-all text-slate-900" 
            />
            <button 
              onClick={handleSend} 
              disabled={(!input.trim() && attachedFiles.length === 0) || isTyping} 
              className="absolute right-3 top-1/2 -translate-y-1/2 px-8 py-4 bg-slate-900 text-white rounded-xl hover:bg-slate-800 disabled:bg-slate-100 disabled:text-slate-300 transition-all font-black text-[10px] uppercase tracking-widest shadow-xl active:scale-95"
            >
              Execute
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatWindow;
