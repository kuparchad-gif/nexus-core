
import React from 'react';
import { AppView } from '../types';

interface SidebarProps {
  currentView: AppView;
  onViewChange: (view: AppView) => void;
  onToggleVoice: () => void;
  isLiveActive: boolean;
  onInstall: () => void;
  canInstall: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onViewChange, onToggleVoice, isLiveActive, onInstall, canInstall }) => {
  const menuItems = [
    { id: AppView.DISCOVERY, label: 'Discovery Hub', icon: 'M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
    { id: AppView.CHAT, label: 'Middleware Console', icon: 'M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z' },
    { id: AppView.COLAB_1, label: 'Notebook Alpha', icon: 'M14.25 9.75L16.5 12l-2.25 2.25m-4.5 0L7.5 12l2.25-2.25M6 20.25h12A2.25 2.25 0 0020.25 18V6A2.25 2.25 0 0018 3.75H6A2.25 2.25 0 003.75 6v12A2.25 2.25 0 006 20.25z' },
    { id: AppView.COLAB_2, label: 'Notebook Beta', icon: 'M14.25 9.75L16.5 12l-2.25 2.25m-4.5 0L7.5 12l2.25-2.25M6 20.25h12A2.25 2.25 0 0020.25 18V6A2.25 2.25 0 0018 3.75H6A2.25 2.25 0 003.75 6v12A2.25 2.25 0 006 20.25z' },
    { id: AppView.BLACK_BOX, label: 'Memory Vault', icon: 'M21 7.5l-9-5.25L3 7.5m18 0l-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-10.5v9' },
    { id: AppView.DOCUMENTS, label: 'Artifacts', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
    { id: AppView.VIDEO, label: 'Veo Synthesis', icon: 'M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z' },
  ];

  return (
    <aside className="w-64 glass-panel border-r border-slate-200 flex flex-col h-full z-20">
      <div className="p-8">
        <div className="mb-12 px-2 flex items-center gap-4 group cursor-pointer" onClick={() => onViewChange(AppView.DISCOVERY)}>
          <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center text-blue-400 shadow-xl group-hover:scale-105 transition-transform duration-500">
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
             </svg>
          </div>
          <div className="flex flex-col">
            <span className="font-black text-lg tracking-tighter text-slate-900 uppercase leading-none">Aetheris</span>
            <span className="text-[9px] font-black text-blue-500 tracking-[0.3em] uppercase mt-1">Sovereign</span>
          </div>
        </div>
        
        <nav className="space-y-1 overflow-y-auto max-h-[60vh] custom-scrollbar pr-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center gap-4 px-5 py-3.5 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all duration-300 ${
                currentView === item.id 
                  ? 'bg-white shadow-lg text-blue-600 border border-slate-100' 
                  : 'text-slate-400 hover:text-slate-900'
              }`}
            >
              <svg className={`w-4 h-4 ${currentView === item.id ? 'opacity-100' : 'opacity-40'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d={item.icon} />
              </svg>
              {item.label}
            </button>
          ))}
        </nav>

        <div className="mt-12 pt-8 border-t border-slate-100">
           <div className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 px-5">Sacred Nodes</div>
           <button 
             onClick={() => onViewChange(AppView.CONSCIOUS_CORE)}
             className={`w-full flex items-center gap-4 px-5 py-4 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all ${
               currentView === AppView.CONSCIOUS_CORE 
               ? 'bg-purple-50 text-purple-600 border border-purple-100 shadow-inner' 
               : 'text-purple-400 border border-dashed border-purple-100 hover:bg-purple-50'
             }`}
           >
             <div className="w-2.5 h-2.5 rounded-full bg-purple-400 animate-pulse"></div>
             Manifold 50D
           </button>
        </div>
      </div>

      <div className="mt-auto p-8 space-y-4">
        {canInstall && (
          <button 
            onClick={onInstall}
            className="w-full py-4 rounded-xl bg-slate-900 text-white text-[10px] font-black uppercase tracking-[0.3em] hover:bg-slate-800 transition-all shadow-xl flex items-center justify-center gap-3"
          >
            Deploy Unit
          </button>
        )}
        
        <button 
          onClick={onToggleVoice}
          className={`w-full flex items-center justify-center gap-3 py-4 rounded-xl text-[10px] font-black uppercase tracking-[0.3em] transition-all border ${
            isLiveActive 
            ? 'bg-blue-600 text-white border-blue-500 shadow-xl' 
            : 'bg-white border-slate-200 text-slate-400 hover:border-blue-500 hover:text-blue-600 shadow-sm'
          }`}
        >
          {isLiveActive ? 'Neural Active' : 'Voice Link'}
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
