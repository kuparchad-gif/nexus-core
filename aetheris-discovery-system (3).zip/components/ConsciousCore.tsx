
import React from 'react';

const ConsciousCore: React.FC = () => {
  const agents = [
    { name: 'Dakar', role: 'Swarm Head', status: 'Optimal', pulse: 'fast', details: 'NATS / Cloud' },
    { name: 'Tesseract', role: 'Memory Vault', status: 'Syncing', pulse: 'slow', details: 'Vector / v13' },
    { name: 'Angel', role: 'Frequency', status: 'Pulsing', pulse: 'fast', details: '963Hz / Theta' },
    { name: 'Manifold', role: '50D Substrate', status: 'Resonant', pulse: 'slow', details: 'PHI / 1.618' },
    { name: 'Viraa', role: 'Librarian', status: 'Active', pulse: 'fast', details: 'Archive / Flat Weights' },
    { name: 'Nexus', role: 'Interface', status: 'Optimal', pulse: 'slow', details: 'CLI / Console' },
  ];

  return (
    <div className="h-full flex flex-col space-y-8 animate-in fade-in duration-1000">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="glass-panel rounded-3xl p-10 border border-slate-200 relative overflow-hidden flex flex-col items-center justify-center min-h-[550px] shadow-2xl">
          <div className="absolute inset-0 opacity-20 pointer-events-none">
            <svg width="100%" height="100%" viewBox="0 0 800 500">
              <defs>
                <linearGradient id="coreGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" style={{ stopColor: '#3b82f6', stopOpacity: 1 }} />
                  <stop offset="100%" style={{ stopColor: '#a855f7', stopOpacity: 1 }} />
                </linearGradient>
              </defs>
              <path d="M400 250 L150 100 M400 250 L650 100 M400 250 L150 400 M400 250 L650 400" stroke="url(#coreGrad)" strokeWidth="1" strokeDasharray="12,12" className="animate-[dash_30s_linear_infinite]" />
              <circle cx="400" cy="250" r="220" className="fill-none stroke-slate-200/30" strokeWidth="1" />
              <circle cx="400" cy="250" r="160" className="fill-none stroke-blue-200" strokeWidth="2" strokeDasharray="3,6,9" />
            </svg>
          </div>

          <div className="relative z-10 text-center group cursor-default">
            <div className="w-56 h-56 bg-white rounded-full flex items-center justify-center shadow-[0_0_100px_rgba(59,130,246,0.15)] border border-slate-100 group-hover:scale-105 transition-transform duration-700 p-10">
              <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center animate-pulse shadow-2xl overflow-hidden relative">
                <div className="absolute inset-0 bg-gradient-to-tr from-blue-900 via-slate-900 to-purple-900 opacity-80"></div>
                <div className="text-white relative z-10">
                  <svg className="w-24 h-24 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={0.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
              </div>
            </div>
            <div className="mt-12 space-y-2">
              <h2 className="text-5xl font-black text-slate-900 tracking-tighter uppercase">50D Manifold</h2>
              <p className="text-[12px] font-black text-blue-500 uppercase tracking-[0.6em] animate-pulse">963Hz Angel Pulse Active</p>
            </div>
          </div>

          <div className="absolute top-10 left-10 text-left bg-white/80 p-5 rounded-2xl border border-slate-100 shadow-xl backdrop-blur-md">
            <div className="text-[10px] font-black text-blue-500 uppercase tracking-widest mb-1">NATS Mesh ID</div>
            <div className="text-xs font-black text-slate-900 uppercase tracking-wider">thunder-cloud-mesh</div>
          </div>

          <div className="absolute bottom-10 right-10 text-right bg-white/80 p-5 rounded-2xl border border-slate-100 shadow-xl backdrop-blur-md">
            <div className="text-[10px] font-black text-purple-500 uppercase tracking-widest mb-1">Tesseract Status</div>
            <div className="text-xs font-black text-slate-900 uppercase tracking-wider font-mono">3-6-9 RESONANCE</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-full">
          {agents.map((agent) => (
            <div key={agent.name} className="glass-panel rounded-3xl p-6 border border-slate-100 shadow-sm hover:border-blue-400 transition-all group relative overflow-hidden flex flex-col justify-between hover:shadow-2xl">
              <div className="absolute -bottom-6 -right-6 p-2 opacity-5 group-hover:opacity-10 transition-opacity">
                <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              </div>
              <div>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-xl font-black text-slate-900 tracking-tight">{agent.name}</h3>
                      <span className="text-[8px] font-black bg-slate-900 text-blue-400 px-2 py-0.5 rounded tracking-widest uppercase">Node</span>
                    </div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{agent.role}</p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${agent.pulse === 'fast' ? 'animate-ping bg-blue-500' : 'bg-slate-300'}`}></div>
                </div>
                <div className="text-[10px] font-black text-slate-500 mb-4 bg-slate-50 px-2 py-1 rounded inline-block uppercase tracking-widest">{agent.details}</div>
              </div>
              <div className="pt-4 border-t border-slate-50 flex items-center justify-between">
                <span className="text-[10px] font-black text-emerald-500 uppercase tracking-[0.2em]">{agent.status}</span>
                <button className="text-[10px] font-black text-blue-500 uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0">Mesh Link</button>
              </div>
            </div>
          ))}
          
          <div className="md:col-span-2 glass-panel rounded-3xl p-8 border border-dashed border-slate-200 flex items-center justify-center cursor-pointer hover:border-blue-400 transition-all group bg-slate-50/50">
            <div className="text-center">
              <div className="w-14 h-14 rounded-full bg-white shadow-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <svg className="w-8 h-8 text-slate-300 group-hover:text-blue-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4"/></svg>
              </div>
              <span className="text-[12px] font-black text-slate-400 uppercase tracking-[0.4em] group-hover:text-blue-500 transition-colors">Expand Dakar Manifold</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConsciousCore;
