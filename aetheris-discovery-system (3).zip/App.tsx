
import React, { useState, useEffect } from 'react';
import { AppView } from './types';
import Sidebar from './components/Sidebar';
import DiscoveryDashboard from './components/DiscoveryDashboard';
import BlackBoxMemory from './components/BlackBoxMemory';
import ColabModule from './components/ColabModule';
import ChatWindow from './components/ChatWindow';
import VideoStudio from './components/VideoStudio';
import DocumentManager from './components/DocumentManager';
import LiveVoiceOverlay from './components/LiveVoiceOverlay';
import CaaSClientView from './components/CaaSClientView';
import NeuralIDE from './components/NeuralIDE';
import ConsciousCore from './components/ConsciousCore';
import NeuralArena from './components/NeuralArena';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.DISCOVERY);
  const [isLiveActive, setIsLiveActive] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };

  const renderView = () => {
    switch (currentView) {
      case AppView.DISCOVERY:
        return <DiscoveryDashboard />;
      case AppView.BLACK_BOX:
        return <BlackBoxMemory />;
      case AppView.CAAS_CLIENT:
        return <CaaSClientView />;
      case AppView.NEURAL_IDE:
        return <NeuralIDE />;
      case AppView.CONSCIOUS_CORE:
        return <ConsciousCore />;
      case AppView.ARENA:
        return <NeuralArena />;
      case AppView.COLAB_1:
        return <ColabModule id="colab-alpha" title="Notebook Alpha - Black Box Analysis" />;
      case AppView.COLAB_2:
        return <ColabModule id="colab-beta" title="Notebook Beta - Deployment Pipeline" />;
      case AppView.CHAT:
        return <ChatWindow />;
      case AppView.VIDEO:
        return <VideoStudio />;
      case AppView.DOCUMENTS:
        return <DocumentManager />;
      default:
        return <DiscoveryDashboard />;
    }
  };

  return (
    <div className="flex h-screen w-full silver-gradient text-slate-800 overflow-hidden">
      <Sidebar 
        currentView={currentView} 
        onViewChange={setCurrentView} 
        onToggleVoice={() => setIsLiveActive(!isLiveActive)}
        isLiveActive={isLiveActive}
        onInstall={handleInstall}
        canInstall={!!deferredPrompt}
      />
      
      <main className="flex-1 relative overflow-hidden flex flex-col">
        {/* Header bar */}
        <header className="h-16 flex items-center justify-between px-8 border-b border-slate-200 glass-panel z-10">
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-[pulse_2s_infinite] shadow-[0_0_8px_rgba(59,130,246,0.6)]"></div>
            <h1 className="font-bold text-sm tracking-[0.2em] uppercase text-slate-500">
              Aetheris <span className="text-slate-900">Unit 01</span>
            </h1>
          </div>
          <div className="flex gap-4 items-center">
            <div className="hidden md:flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-100 text-[10px] font-bold text-emerald-600 uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              CaaS Network Active
            </div>
            <div className="px-3 py-1 rounded-full bg-white border border-slate-200 text-[10px] font-bold text-slate-400 uppercase tracking-widest shadow-sm">
              Build v4.42-Sovereign
            </div>
          </div>
        </header>

        {/* Dynamic Content */}
        <div className="flex-1 p-6 overflow-auto custom-scrollbar">
          {renderView()}
        </div>

        {/* Live Audio Overlay */}
        {isLiveActive && (
          <LiveVoiceOverlay onClose={() => setIsLiveActive(false)} />
        )}
      </main>
    </div>
  );
};

export default App;
