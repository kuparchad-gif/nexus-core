
export enum AppView {
  DISCOVERY = 'discovery',
  BLACK_BOX = 'black_box',
  CAAS_CLIENT = 'caas_client',
  NEURAL_IDE = 'neural_ide',
  CONSCIOUS_CORE = 'conscious_core',
  COLAB_1 = 'colab_1',
  COLAB_2 = 'colab_2',
  CHAT = 'chat',
  VIDEO = 'video',
  DOCUMENTS = 'documents'
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface DiscoveryResource {
  id: string;
  name: string;
  type: string;
  status: 'active' | 'idle' | 'processing';
  lastSeen: string;
}

export interface MemoryEntry {
  id: string;
  timestamp: string;
  content: string;
  tags: string[];
}

export interface CaaSMetrics {
  tier: string;
  retention: number;
  apiCalls: number;
  learningCycles: number;
  sovereigntyLevel: number;
}

export interface FileObject {
  name: string;
  size: string;
  type: string;
  date: string;
  blob?: Blob;
}
