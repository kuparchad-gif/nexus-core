
import React, { useState } from 'react';

interface ColabModuleProps {
  id: string;
  title: string;
}

const ColabModule: React.FC<ColabModuleProps> = ({ title }) => {
  const [activeCell, setActiveCell] = useState(0);
  
  const cells = [
    {
      type: 'code',
      content: `from black_box import BlackBox\n\n# Initialize Memory Vault\nbox = BlackBox()\nbox.add_memory("Discovery session initialized at tunnel endpoint.", tags=["system", "boot"])\n\nprint("Memory stored in Black Box.")`,
      output: '[*] Memory stored (ID: b8a2e1f4).\nMemory stored in Black Box.'
    },
    {
      type: 'markdown',
      content: '### Memory Recall Logic\nThe following retrieves all system-tagged memories from the vault.',
      output: null
    },
    {
      type: 'code',
      content: `results = box.recall(tag="system")\nfor res in results:\n    print(f"[{res['id']}] {res['content']}")`,
      output: '[b8a2e1f4] Discovery session initialized at tunnel endpoint.'
    },
    {
      type: 'code',
      content: `# Initiate Discovery Protocol\nfrom discovery_protocol import DiscoveryProtocol\n\ndiscovery = DiscoveryProtocol(endpoint="trycloudflare.com")\ndiscovery.scan_and_map()`,
      output: '📡 Scanning Cloudflare tunnel...\n✅ Tunnel active at: https://template-exp-dust-commit.trycloudflare.com\nResources identified: 4 nodes active.'
    }
  ];

  return (
    <div className="h-full flex flex-col glass-panel rounded-2xl border border-slate-200 overflow-hidden shadow-sm animate-in fade-in zoom-in-95 duration-300">
      <div className="bg-slate-50 border-b border-slate-200 p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-slate-900 flex items-center justify-center text-blue-400 font-bold text-xs italic">
            CO
          </div>
          <div>
            <h3 className="font-bold text-sm text-slate-800">{title}</h3>
            <p className="text-[10px] text-slate-400 font-medium">Remote: instance-2201-us-central | Python 3.11</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 mr-4 px-3 py-1 bg-white border border-slate-200 rounded text-[9px] font-bold text-slate-400 uppercase tracking-widest">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> RAM: 4.2GB / 16GB
          </div>
          <button className="px-3 py-1.5 rounded text-xs font-bold bg-white border border-slate-200 text-slate-600 hover:bg-slate-50">Save</button>
          <button className="px-3 py-1.5 rounded text-xs font-bold bg-blue-500 text-white shadow-sm hover:bg-blue-600 flex items-center gap-2">
            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
            Execute All
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto bg-white p-6 space-y-6">
        {cells.map((cell, idx) => (
          <div 
            key={idx} 
            className={`group relative border-l-2 transition-all pl-6 py-2 ${
              activeCell === idx ? 'border-blue-500 bg-blue-50/10' : 'border-slate-100'
            }`}
            onClick={() => setActiveCell(idx)}
          >
            {cell.type === 'markdown' ? (
              <div className="prose prose-sm text-slate-600 font-medium">
                {cell.content}
              </div>
            ) : (
              <div className="space-y-3">
                <div className="bg-slate-50 rounded-lg p-4 font-mono text-sm border border-slate-100 text-slate-700 whitespace-pre shadow-inner">
                  {cell.content}
                </div>
                {cell.output && (
                  <div className="bg-slate-900 rounded-lg p-4 font-mono text-xs text-blue-300 whitespace-pre leading-relaxed border border-slate-800">
                    <span className="text-slate-500 mb-2 block uppercase text-[8px] font-bold tracking-[0.2em] border-b border-slate-800 pb-1">Cell Output</span>
                    {cell.output}
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ColabModule;
