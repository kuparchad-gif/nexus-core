
import React, { useState } from 'react';
import { AreaChart, Area, XAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const mockData = [
  { name: '00:00', resources: 40, latency: 24 },
  { name: '04:00', resources: 30, latency: 18 },
  { name: '08:00', resources: 20, latency: 45 },
  { name: '12:00', resources: 27, latency: 30 },
  { name: '16:00', resources: 18, latency: 20 },
  { name: '20:00', resources: 23, latency: 25 },
  { name: '24:00', resources: 34, latency: 22 },
];

const DiscoveryDashboard: React.FC = () => {
  const [resources] = useState([
    { id: 'BB-001', name: 'Black Box Core', type: 'Database', status: 'active', load: '12%' },
    { id: 'TUN-CLD', name: 'Cloudflare Tunnel', type: 'Network', status: 'active', load: 'Nominal' },
    { id: 'DSC-PRT', name: 'Discovery Protocol', type: 'Logic', status: 'processing', load: '89%' },
    { id: 'MEM-VLT', name: 'Memory Vault', type: 'Storage', status: 'active', load: '2%' },
  ]);

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Cloudflare Tunnel Status Banner */}
      <div className="glass-panel rounded-2xl p-4 flex items-center justify-between border-l-4 border-l-blue-400 border border-slate-200">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-500">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
          </div>
          <div>
            <div className="text-[10px] font-bold text-blue-500 uppercase tracking-[0.2em]">Active Tunnel Endpoint</div>
            <div className="font-mono text-sm text-slate-800">template-exp-dust-commit.trycloudflare.com</div>
          </div>
        </div>
        <a href="https://template-exp-dust-commit.trycloudflare.com/docs" target="_blank" rel="noreferrer" className="px-4 py-2 rounded-lg bg-white border border-slate-200 text-[10px] font-bold uppercase tracking-widest text-slate-500 hover:bg-slate-50 transition-all">
          API Documentation
        </a>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Resource List */}
        <div className="lg:col-span-2 glass-panel rounded-2xl p-6 shadow-sm border border-slate-200">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-slate-800">Discovery Protocol Pulse</h2>
            <div className="flex gap-2">
              <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-50 text-[10px] font-bold text-slate-400 uppercase tracking-widest border border-slate-100">
                Scanning Subnet...
              </span>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-slate-400 border-b border-slate-100 uppercase text-[10px] font-bold tracking-widest">
                  <th className="text-left pb-4 font-bold">UID</th>
                  <th className="text-left pb-4 font-bold">Node Name</th>
                  <th className="text-left pb-4 font-bold">Classification</th>
                  <th className="text-left pb-4 font-bold">Signal</th>
                  <th className="text-right pb-4 font-bold">Throughput</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {resources.map((res) => (
                  <tr key={res.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="py-4 mono text-slate-400 text-xs">{res.id}</td>
                    <td className="py-4 font-medium text-slate-700">{res.name}</td>
                    <td className="py-4">
                      <span className="px-2 py-1 rounded-full bg-slate-100 text-slate-500 text-[10px] font-bold uppercase tracking-wider">
                        {res.type}
                      </span>
                    </td>
                    <td className="py-4">
                      <div className="flex items-center gap-2">
                        <div className={`w-1.5 h-1.5 rounded-full ${
                          res.status === 'active' ? 'bg-emerald-400' : 
                          res.status === 'processing' ? 'bg-blue-400 animate-pulse' : 'bg-slate-300'
                        }`}></div>
                        <span className="capitalize text-xs font-medium">{res.status}</span>
                      </div>
                    </td>
                    <td className="py-4 text-right mono font-medium text-slate-600">{res.load}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* System Stats */}
        <div className="glass-panel rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col">
          <h2 className="text-lg font-bold text-slate-800 mb-6 uppercase text-xs tracking-[0.2em]">Signal Latency</h2>
          <div className="flex-1 h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockData}>
                <defs>
                  <linearGradient id="colorLat" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" hide />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(255, 255, 255, 0.9)', 
                    borderRadius: '12px', 
                    border: '1px solid #e2e8f0',
                    fontSize: '12px'
                  }} 
                />
                <Area type="monotone" dataKey="latency" stroke="#3b82f6" fillOpacity={1} fill="url(#colorLat)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-6 pt-6 border-t border-slate-100">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-500 font-medium uppercase tracking-widest text-[9px]">Average Discovery Time</span>
              <span className="text-slate-900 font-bold">14ms</span>
            </div>
            <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
              <div className="bg-blue-400 h-full w-[85%]" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DiscoveryDashboard;
