
import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';

interface LiveVoiceOverlayProps {
  onClose: () => void;
}

const LiveVoiceOverlay: React.FC<LiveVoiceOverlayProps> = ({ onClose }) => {
  const [isConnecting, setIsConnecting] = useState(true);
  const [transcription, setTranscription] = useState('');
  const [visualizerData, setVisualizerData] = useState<number[]>(new Array(40).fill(5));
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTime = useRef(0);
  const sources = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Function implementation for base64 encoding/decoding as required by guidelines
  const encode = (bytes: Uint8Array) => {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number) => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  useEffect(() => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    let session: any = null;

    const initLive = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
        const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        audioContextRef.current = outputCtx;

        const sessionPromise = ai.live.connect({
          model: 'gemini-2.5-flash-native-audio-preview-12-2025',
          callbacks: {
            onopen: () => {
              setIsConnecting(false);
              const source = inputCtx.createMediaStreamSource(stream);
              const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
              scriptProcessor.onaudioprocess = (e) => {
                const inputData = e.inputBuffer.getChannelData(0);
                const l = inputData.length;
                const int16 = new Int16Array(l);
                for (let i = 0; i < l; i++) int16[i] = inputData[i] * 32768;
                
                sessionPromise.then((s) => {
                  s.sendRealtimeInput({
                    media: {
                      data: encode(new Uint8Array(int16.buffer)),
                      mimeType: 'audio/pcm;rate=16000',
                    }
                  });
                });

                // Simple visualizer update
                const avg = inputData.reduce((a, b) => a + Math.abs(b), 0) / l;
                setVisualizerData(prev => [...prev.slice(1), 5 + avg * 100]);
              };
              source.connect(scriptProcessor);
              scriptProcessor.connect(inputCtx.destination);
            },
            onmessage: async (message: LiveServerMessage) => {
              if (message.serverContent?.outputTranscription) {
                setTranscription(prev => (prev + ' ' + message.serverContent?.outputTranscription?.text).slice(-200));
              }

              const audioStr = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
              if (audioStr) {
                nextStartTime.current = Math.max(nextStartTime.current, outputCtx.currentTime);
                const buffer = await decodeAudioData(decode(audioStr), outputCtx, 24000, 1);
                const source = outputCtx.createBufferSource();
                source.buffer = buffer;
                source.connect(outputCtx.destination);
                source.start(nextStartTime.current);
                nextStartTime.current += buffer.duration;
                sources.current.add(source);
                source.onended = () => sources.current.delete(source);
              }

              if (message.serverContent?.interrupted) {
                sources.current.forEach(s => s.stop());
                sources.current.clear();
                nextStartTime.current = 0;
              }
            },
            onerror: (e) => console.error('Live Error', e),
            onclose: () => onClose()
          },
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
            systemInstruction: 'You are Aetheris Voice Synthesis. You help with deployment discovery through voice conversation. Keep answers concise.',
            outputAudioTranscription: {}
          }
        });

        session = await sessionPromise;
      } catch (err) {
        console.error(err);
        onClose();
      }
    };

    initLive();

    return () => {
      if (session) session.close();
      if (audioContextRef.current) audioContextRef.current.close();
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center pointer-events-none p-12">
      <div className="glass-panel w-full max-w-2xl rounded-3xl border border-blue-200/50 shadow-2xl pointer-events-auto p-8 neon-accent-blue overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-400 via-purple-400 to-blue-400"></div>
        
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center relative">
              <div className="absolute inset-0 bg-blue-400 rounded-full animate-ping opacity-20"></div>
              <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
            </div>
            <div>
              <h3 className="font-bold text-slate-800">Aetheris Synthesis Active</h3>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                {isConnecting ? 'Establishing Neural Link...' : 'Listening for instructions'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-red-500 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
        </div>

        <div className="h-24 flex items-center justify-center gap-1.5 mb-6">
          {visualizerData.map((val, i) => (
            <div 
              key={i} 
              className="w-1 bg-blue-400 rounded-full transition-all duration-75" 
              style={{ height: `${val}%`, opacity: 0.2 + (i / visualizerData.length) * 0.8 }}
            ></div>
          ))}
        </div>

        <div className="bg-slate-50/50 rounded-xl p-4 border border-slate-100 min-h-[60px]">
          <p className="text-xs text-slate-500 italic font-medium leading-relaxed">
            {transcription || "System ready. 'Aetheris, what is the status of node Black Box 1?'"}
          </p>
        </div>
      </div>
    </div>
  );
};

export default LiveVoiceOverlay;
