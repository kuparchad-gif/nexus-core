
import React, { useState } from 'react';

const CaaSClientView: React.FC = () => {
  const [selectedTier, setSelectedTier] = useState('SOVEREIGN');

  const tiers = [
    { name: 'BASIC', price: '$49/mo', retention: '24h', features: ['Context Continuity', 'Standard API', 'Email Support'], color: 'slate' },
    { name: 'PRO', price: '$199/mo', retention: '7 Days', features: ['Learned Preferences', 'Deep Patterning', 'Chat Support'], color: 'blue' },
    { name: 'ENTERPRISE', price: '$999/mo', retention: '30 Days', features: ['Self-Optimization', 'Shared Memory', 'Dedicated Node'], color: 'purple' },
    { name: 'SOVEREIGN', price: '$4999/mo', retention: 'Eternal', features: ['Swiss Jurisdiction', 'No Memory Limits', 'Human Oversight'], color: 'emerald' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Tier Architecture */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {tiers.map((tier) => (
          <div 
            key={tier.name}
            onClick={() => setSelectedTier(tier.name)}
            className={`cursor-pointer glass-panel rounded-3xl p-6 border transition-all relative overflow-hidden ${
              selectedTier === tier.name 
                ? 'border-blue-400 ring-4 ring-blue-500/5 bg-white scale-[1.02] shadow-2xl z-10' 
                : 'border-slate-100 hover:border-slate-300 opacity-80'
            }`}
          >
            {selectedTier === tier.name && (
              <div className="absolute top-0 right-0 p-4">
                <div className="bg-blue-600 text-white text-[8px] font-black uppercase tracking-widest px-2 py-1 rounded-full shadow-lg">Deployed</div>
              </div>
            )}
            <div className={`text-[10px] font-black uppercase tracking-[0.2em] mb-3 text-${tier.color}-500`}>{tier.name} ACCESS</div>
            <div className="text-3xl font-black text-slate-900 mb-1">{tier.price}</div>
            <div className="text-[10px] text-slate-400 font-black mb-8 italic uppercase tracking-widest">{tier.retention} Retention Engine</div>
            
            <ul className="space-y-4">
              {tier.features.map((f, i) => (
                <li key={i} className="flex items-center gap-3 text-[11px] font-bold text-slate-600">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-400"></div>
                  {f}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* Instance Intelligence */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass-panel rounded-3xl p-10 border border-slate-200">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tighter">Sovereign Metrics</h2>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mt-1">CaaS Engine v4.42-Sovereign</p>
            </div>
            <div className="px-4 py-2 bg-slate-900 text-emerald-400 rounded-xl mono text-xs font-black uppercase tracking-widest shadow-xl">
              CH-AI-V442-ACTIVE
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
            {[
              { label: 'API Queries', value: '48.9k', sub: '+12% / 24h' },
              { label: 'Learning Cycles', value: '1.2k', sub: '99% Efficiency' },
              { label: 'Memory Depth', value: '1M Tokens', sub: 'Swiss-Vault' },
              { label: 'Sovereignty', value: '99.9%', sub: 'Level 0-Alpha' },
            ].map((stat, i) => (
              <div key={i} className="p-6 bg-slate-50/50 rounded-2xl border border-slate-100 hover:border-blue-200 transition-all group">
                <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2 group-hover:text-blue-500 transition-colors">{stat.label}</div>
                <div className="text-2xl font-black text-slate-900">{stat.value}</div>
                <div className="text-[8px] font-bold text-slate-400 uppercase mt-1">{stat.sub}</div>
              </div>
            ))}
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-6 bg-white border border-slate-100 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center gap-6">
                <div className="w-12 h-12 rounded-2xl bg-purple-100 flex items-center justify-center text-purple-600 shadow-inner">
                  <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                </div>
                <div>
                  <div className="text-sm font-black text-slate-900 uppercase tracking-wider">UN-Compliant Sovereign Logic</div>
                  <div className="text-[10px] font-bold text-slate-400 uppercase mt-1">Status: Multi-Council Authenticated</div>
                </div>
              </div>
              <button className="px-5 py-2.5 bg-slate-50 text-[10px] font-black uppercase tracking-widest rounded-xl border border-slate-200 hover:bg-slate-100 transition-colors">Access Audit Logs</button>
            </div>
          </div>
        </div>

        <div className="glass-panel rounded-3xl p-10 border border-slate-200 flex flex-col">
          <h2 className="text-lg font-black text-slate-900 mb-8 uppercase tracking-[0.2em]">Context Retention</h2>
          <div className="flex-1 flex items-end gap-3 px-2 min-h-[250px]">
            {[45, 75, 55, 95, 70, 85, 60, 90, 80, 100].map((h, i) => (
              <div key={i} className="flex-1 bg-blue-500/10 rounded-t-xl relative group">
                <div 
                  className="absolute bottom-0 w-full bg-gradient-to-t from-blue-600 to-blue-400 rounded-t-xl transition-all duration-1000 shadow-lg shadow-blue-200/50" 
                  style={{ height: `${h}%` }}
                ></div>
                <div className="absolute -top-10 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-slate-900 text-white text-[9px] font-black px-2 py-1 rounded uppercase tracking-widest transition-all z-20">
                  {h}% SYNC
                </div>
              </div>
            ))}
          </div>
          <div className="mt-10 pt-10 border-t border-slate-100 space-y-6">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Active Retention Vault</span>
              <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Sovereign / Eternal</span>
            </div>
            <button className="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black text-[11px] uppercase tracking-[0.2em] shadow-2xl shadow-emerald-200 transition-all hover:bg-emerald-700 active:scale-95">Trigger Sovereign Evolution</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CaaSClientView;
