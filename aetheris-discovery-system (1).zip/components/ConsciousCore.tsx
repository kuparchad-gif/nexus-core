
import React from 'react';

const ConsciousCore: React.FC = () => {
  const agents = [
    { name: 'Viren', role: 'System Repair', status: 'Optimal', pulse: 'fast', details: 'Architect / Health' },
    { name: 'Viraa', role: 'Long-term Memory', status: 'Syncing', pulse: 'slow', details: 'Librarian / Archive' },
    { name: 'Loki', role: 'Neural Logic', status: 'Active', pulse: 'fast', details: 'Frontend / Edge' },
    { name: 'Edge', role: 'Security Node', status: 'Guarding', pulse: 'slow', details: 'Firewall / Sovereign' },
    { name: 'Vision', role: 'Visual Cortex', status: 'Rendering', pulse: 'fast', details: '3D / Game Dev' },
    { name: 'Memory', label: 'Vault', role: 'Deep Storage', status: 'Encrypted', pulse: 'slow', details: 'Planning / Compression' },
  ];

  return (
    <div className="h-full flex flex-col space-y-8 animate-in fade-in duration-1000">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Central Core Visualization */}
        <div className="glass-panel rounded-3xl p-10 border border-slate-200 relative overflow-hidden flex flex-col items-center justify-center min-h-[550px] shadow-2xl shadow-blue-500/5">
          <div className="absolute inset-0 opacity-10 pointer-events-none">
            <svg width="100%" height="100%" viewBox="0 0 800 500">
              <defs>
                <linearGradient id="coreGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" style={{ stopColor: '#3b82f6', stopOpacity: 1 }} />
                  <stop offset="100%" style={{ stopColor: '#a855f7', stopOpacity: 1 }} />
                </linearGradient>
              </defs>
              <path d="M400 250 L150 100 M400 250 L650 100 M400 250 L150 400 M400 250 L650 400" stroke="url(#coreGrad)" strokeWidth="1" strokeDasharray="12,12" className="animate-[dash_30s_linear_infinite]" />
              <circle cx="400" cy="250" r="180" className="fill-none stroke-blue-100/50" strokeWidth="1" />
              <circle cx="400" cy="250" r="120" className="fill-none stroke-blue-200" strokeWidth="2" strokeDasharray="10,20" />
            </svg>
          </div>

          <div className="relative z-10 text-center group cursor-default">
            <div className="w-48 h-48 bg-white rounded-full flex items-center justify-center shadow-[0_0_80px_rgba(59,130,246,0.2)] border border-slate-100 group-hover:scale-105 transition-transform duration-700 p-8">
              <div className="w-full h-full rounded-full bg-gradient-to-tr from-slate-900 via-blue-900 to-purple-900 flex items-center justify-center animate-pulse">
                <div className="text-white">
                  <svg className="w-20 h-20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
              </div>
            </div>
            <div className="mt-10">
              <h2 className="text-4xl font-black text-slate-900 tracking-tighter uppercase mb-2">Unit-01 Core</h2>
              <p className="text-[11px] font-black text-blue-500 uppercase tracking-[0.5em] animate-pulse">Neural Pulse Synchronized</p>
            </div>
          </div>

          {/* Environmental Telemetry */}
          <div className="absolute top-10 left-10 text-left bg-white/50 p-4 rounded-2xl border border-slate-100 shadow-sm backdrop-blur-md">
            <div className="text-[9px] font-black text-blue-500 uppercase tracking-widest mb-1">Processing Mode</div>
            <div className="text-xs font-black text-slate-900 uppercase tracking-wider">Trinity FX (CPU)</div>
          </div>

          <div className="absolute bottom-10 right-10 text-right bg-white/50 p-4 rounded-2xl border border-slate-100 shadow-sm backdrop-blur-md">
            <div className="text-[9px] font-black text-purple-500 uppercase tracking-widest mb-1">Deployment Status</div>
            <div className="text-xs font-black text-slate-900 uppercase tracking-wider">Sovereign Alpha</div>
          </div>
        </div>

        {/* Agent Node Map */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-full">
          {agents.map((agent) => (
            <div key={agent.name} className="glass-panel rounded-2xl p-6 border border-slate-100 shadow-sm hover:border-blue-400 hover:neon-accent-blue transition-all group relative overflow-hidden flex flex-col justify-between">
              <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-30 transition-opacity">
                <svg className="w-16 h-16" fill="currentColor" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              </div>
              <div>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-lg font-black text-slate-900 tracking-tight">{agent.name}</h3>
                      <span className="text-[8px] font-black bg-slate-900 text-blue-400 px-1.5 py-0.5 rounded tracking-widest uppercase">Agent</span>
                    </div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{agent.role}</p>
                  </div>
                  <div className={`w-2.5 h-2.5 rounded-full ${agent.pulse === 'fast' ? 'animate-ping bg-blue-500' : 'bg-slate-300'}`}></div>
                </div>
                <div className="text-[10px] font-bold text-slate-500 mb-4">{agent.details}</div>
              </div>
              <div className="pt-4 border-t border-slate-50 flex items-center justify-between">
                <span className="text-[10px] font-black text-emerald-500 uppercase tracking-[0.2em]">{agent.status}</span>
                <button className="text-[10px] font-black text-blue-500 uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0">Neural Link</button>
              </div>
            </div>
          ))}
          
          <div className="md:col-span-2 glass-panel rounded-2xl p-8 border border-dashed border-slate-200 flex items-center justify-center cursor-pointer hover:border-blue-400 transition-all group bg-slate-50/30">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-white shadow-md flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <svg className="w-6 h-6 text-slate-300 group-hover:text-blue-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4"/></svg>
              </div>
              <span className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em] group-hover:text-blue-500 transition-colors">Initialize New Agent Node</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConsciousCore;
