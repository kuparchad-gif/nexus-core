
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";

const VideoStudio: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [status, setStatus] = useState('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const generateVideo = async () => {
    if (!prompt) return;
    
    setIsGenerating(true);
    setStatus('Initializing Veo Engine...');
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const payload: any = {
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt,
        config: {
          numberOfVideos: 1,
          resolution: '1080p',
          aspectRatio: '16:9'
        }
      };

      if (image) {
        const base64Data = image.split(',')[1];
        payload.image = {
          imageBytes: base64Data,
          mimeType: 'image/png'
        };
      }

      let operation = await ai.models.generateVideos(payload);
      
      setStatus('Processing temporal synthesis... (this may take a few minutes)');
      
      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await ai.operations.getVideosOperation({ operation: operation });
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
      const blob = await videoResponse.blob();
      setVideoUrl(URL.createObjectURL(blob));
      setStatus('Synthesis complete.');
    } catch (error) {
      console.error(error);
      setStatus('Synthesis failed. Please verify API configuration.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="h-full grid grid-cols-1 lg:grid-cols-2 gap-6 animate-in fade-in slide-in-from-left-4 duration-300">
      <div className="glass-panel rounded-2xl p-8 border border-slate-200 flex flex-col space-y-6">
        <div>
          <h2 className="text-xl font-bold text-slate-800 mb-2">Veo Visual Synthesis</h2>
          <p className="text-sm text-slate-500">Generate hyper-realistic deployment visualizations using Veo 3.1 Fast.</p>
        </div>

        <div className="space-y-4">
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest">Source Frame (Optional)</label>
          <div 
            className="border-2 border-dashed border-slate-200 rounded-2xl h-48 flex flex-col items-center justify-center bg-slate-50 cursor-pointer hover:border-blue-400 transition-colors relative overflow-hidden group"
            onClick={() => document.getElementById('video-file-input')?.click()}
          >
            {image ? (
              <img src={image} className="absolute inset-0 w-full h-full object-cover" alt="Upload preview" />
            ) : (
              <div className="text-center p-6">
                <svg className="w-10 h-10 text-slate-300 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4v16m8-8H4" />
                </svg>
                <p className="text-xs text-slate-400 font-medium">Click to upload reference image</p>
              </div>
            )}
            <input 
              id="video-file-input" 
              type="file" 
              accept="image/*" 
              className="hidden" 
              onChange={handleFileChange} 
            />
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest">Prompt Description</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="A high-tech laboratory where data flows like liquid silver..."
              className="w-full h-32 p-4 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-sm"
            />
          </div>

          <button
            onClick={generateVideo}
            disabled={isGenerating || !prompt}
            className="w-full py-4 bg-slate-900 text-white rounded-xl font-bold uppercase tracking-widest text-xs hover:bg-slate-800 disabled:bg-slate-200 disabled:text-slate-400 transition-all flex items-center justify-center gap-3"
          >
            {isGenerating ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                Generating Synthesis...
              </>
            ) : 'Initiate Veo Generation'}
          </button>
        </div>
      </div>

      <div className="glass-panel rounded-2xl p-8 border border-slate-200 flex flex-col">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Output Preview</h3>
        <div className="flex-1 bg-slate-900 rounded-2xl flex flex-col items-center justify-center relative overflow-hidden border border-slate-800">
          {videoUrl ? (
            <video src={videoUrl} controls className="w-full h-full object-contain" autoPlay loop />
          ) : (
            <div className="text-center">
              <div className={`w-16 h-16 border-4 border-slate-800 border-t-blue-500 rounded-full mb-4 mx-auto ${isGenerating ? 'animate-spin' : ''}`}></div>
              <p className="text-slate-500 text-xs font-medium px-12">{status || 'Awaiting synthesis parameters...'}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VideoStudio;
