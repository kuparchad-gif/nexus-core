
import React, { useState, useRef, useEffect } from 'react';
import { FileObject } from '../types';

const DocumentManager: React.FC = () => {
  const [docs, setDocs] = useState<FileObject[]>([
    { name: 'Black_Box_Architecture.pdf', size: '2.4 MB', type: 'Technical Doc', date: '2024-05-12' },
    { name: 'Discovery_Protocol_Specs.v3', size: '842 KB', type: 'Protocol Spec', date: '2024-05-14' },
    { name: 'Deploy_Pipeline_Alpha.yml', size: '12 KB', type: 'Configuration', date: '2024-05-15' },
    { name: 'Security_Audit_Report.docx', size: '4.1 MB', type: 'Report', date: '2024-05-10' },
  ]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load user files from local storage simulation if they were uploaded
  useEffect(() => {
    const savedDocs = localStorage.getItem('aetheris_docs');
    if (savedDocs) {
      const parsed = JSON.parse(savedDocs);
      // Filter out duplicates if needed, but for now just merge
      setDocs(prev => [...parsed, ...prev.filter(p => !parsed.some((s: any) => s.name === p.name))]);
    }
  }, []);

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const newDoc: FileObject = {
        name: file.name,
        size: formatSize(file.size),
        type: file.type || 'Binary Resource',
        date: new Date().toISOString().split('T')[0],
        blob: file
      };
      const updatedDocs = [newDoc, ...docs.filter(d => d.name !== newDoc.name)];
      setDocs(updatedDocs);
      
      // Store metadata in localStorage
      const userDocs = updatedDocs.filter(d => d.blob);
      localStorage.setItem('aetheris_docs', JSON.stringify(userDocs.map(d => ({ ...d, blob: undefined }))));
    }
  };

  const handleDownload = (doc: FileObject) => {
    let url;
    if (doc.blob) {
      url = URL.createObjectURL(doc.blob);
    } else {
      const dummyBlob = new Blob([`System resource: ${doc.name}. Context: Sterile Aetheris Environment.`], { type: 'text/plain' });
      url = URL.createObjectURL(dummyBlob);
    }
    
    const a = document.createElement('a');
    a.href = url;
    a.download = doc.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-700">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass-panel rounded-3xl p-10 border border-slate-200 shadow-2xl">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tighter">Knowledge Vault</h2>
              <p className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em] mt-1">Binary Object Repository</p>
            </div>
            <div className="flex gap-3">
              <input 
                type="file" 
                className="hidden" 
                ref={fileInputRef} 
                onChange={handleUpload}
              />
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="text-[10px] font-black bg-slate-900 text-white px-6 py-3.5 rounded-2xl hover:bg-slate-800 transition-all uppercase tracking-[0.2em] shadow-xl shadow-slate-200 flex items-center gap-3"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                Upload Resource
              </button>
            </div>
          </div>
          
          <div className="space-y-4">
            {docs.map((doc, idx) => (
              <div key={idx} className="flex items-center justify-between p-6 rounded-3xl border border-slate-50 bg-white/50 hover:bg-white hover:border-blue-200 hover:shadow-xl hover:shadow-blue-500/5 transition-all group cursor-default">
                <div className="flex items-center gap-6">
                  <div className="w-14 h-14 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-600 transition-all shadow-inner">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-black text-base text-slate-900 tracking-tight">{doc.name}</h4>
                    <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-1">{doc.type} • {doc.size}</p>
                  </div>
                </div>
                <div className="flex items-center gap-10">
                  <div className="hidden xl:block text-right">
                    <div className="text-[9px] text-slate-300 font-black uppercase tracking-widest mb-1">Classification</div>
                    <div className="text-[10px] font-black text-slate-800 uppercase tracking-widest bg-slate-100 px-2 py-0.5 rounded">Secure</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[9px] text-slate-300 font-black uppercase tracking-widest mb-1">Indexed</div>
                    <div className="text-xs text-slate-600 font-black">{doc.date}</div>
                  </div>
                  <button 
                    onClick={() => handleDownload(doc)}
                    className="p-3.5 rounded-xl bg-slate-50 text-slate-400 hover:bg-blue-600 hover:text-white hover:shadow-lg hover:shadow-blue-200 transition-all border border-slate-100"
                    title="Download System Copy"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-panel rounded-3xl p-10 border border-slate-200 flex flex-col shadow-2xl relative overflow-hidden group">
          <div className="absolute -top-20 -right-20 w-64 h-64 bg-blue-500/5 rounded-full blur-[80px] group-hover:bg-blue-500/10 transition-colors"></div>
          <h2 className="text-xl font-black text-slate-900 mb-10 tracking-[0.2em] uppercase">Storage Pulse</h2>
          <div className="flex-1 bg-slate-50/50 border border-slate-100 rounded-[2.5rem] flex flex-col items-center justify-center relative overflow-hidden shadow-inner">
            {/* Perspective Grid Background */}
            <div className="absolute inset-0 opacity-[0.03] pointer-events-none">
              <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                <path d="M0 100 L50 0 L100 100" fill="none" stroke="currentColor" strokeWidth="0.5" />
                <path d="M0 80 L100 80 M0 60 L100 60 M0 40 L100 40 M0 20 L100 20" fill="none" stroke="currentColor" strokeWidth="0.2" />
              </svg>
            </div>
            
            <div className="relative z-10 text-center px-10">
              <div className="w-32 h-32 mx-auto mb-10 relative group">
                <div className="absolute inset-0 bg-blue-500/10 rounded-3xl rotate-[30deg] animate-[spin_15s_linear_infinite] group-hover:bg-blue-500/20 transition-all"></div>
                <div className="absolute inset-4 bg-purple-500/10 rounded-2xl -rotate-[15deg] animate-[spin_25s_linear_infinite] group-hover:bg-purple-500/20 transition-all"></div>
                <div className="absolute inset-8 glass-panel border border-white/90 rounded-2xl flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform duration-500">
                  <svg className="w-12 h-12 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                  </svg>
                </div>
              </div>
              <h3 className="text-base font-black text-slate-900 uppercase tracking-[0.3em] mb-4">Neural Data Mapping</h3>
              <p className="text-[11px] text-slate-400 font-black uppercase tracking-[0.15em] leading-relaxed">Topological visualization of the Black Box knowledge graph.</p>
              <button className="mt-10 px-8 py-4 bg-white border border-slate-200 rounded-2xl text-[10px] font-black uppercase tracking-[0.3em] text-slate-500 hover:border-blue-400 hover:text-blue-600 transition-all shadow-md hover:shadow-xl active:scale-95">Initiate Scan</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentManager;
