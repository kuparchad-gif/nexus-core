
import React from 'react';
import { AppView } from '../types';

interface SidebarProps {
  currentView: AppView;
  onViewChange: (view: AppView) => void;
  onToggleVoice: () => void;
  isLiveActive: boolean;
  onInstall: () => void;
  canInstall: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onViewChange, onToggleVoice, isLiveActive, onInstall, canInstall }) => {
  const menuItems = [
    { id: AppView.DISCOVERY, label: 'Discovery', icon: 'M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
    { id: AppView.CAAS_CLIENT, label: 'CaaS Client', icon: 'M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 013 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5 0h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 00-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 01-1.125-1.125V15m1.5 1.5v-.75A.75.75 0 003 15h-.75M15 10.5a3 3 0 11-6 0 3 3 0 016 0zm3 0h.008v.008H18V10.5zm-12 0h.008v.008H6V10.5z' },
    { id: AppView.CONSCIOUS_CORE, label: 'Hypercore', icon: 'M9 4.5v15m6-15v15m-10.875-15h15.75c.621 0 1.125.504 1.125 1.125V18.375c0 .621-.504 1.125-1.125 1.125H4.125C3.504 21 3 20.496 3 19.875V5.625C3 5.004 3.504 4.5 4.125 4.5z' },
    { id: AppView.NEURAL_IDE, label: 'Neural IDE', icon: 'M14.25 9.75L16.5 12l-2.25 2.25m-4.5 0L7.5 12l2.25-2.25M6 20.25h12A2.25 2.25 0 0020.25 18V6A2.25 2.25 0 0018 3.75H6A2.25 2.25 0 003.75 6v12A2.25 2.25 0 006 20.25z' },
    { id: AppView.BLACK_BOX, label: 'Vault Registry', icon: 'M21 7.5l-9-5.25L3 7.5m18 0l-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-10.5v9' },
    { id: AppView.CHAT, label: 'Synthesis AI', icon: 'M7.5 8.25h9m-9 3H12m-9.75 1.51c0 1.6 1.123 2.994 2.707 3.227 1.129.166 2.27.293 3.423.379.35.026.67.21.865.501L12 21l2.755-4.133a1.14 1.14 0 01.865-.501 48.172 48.172 0 003.423-.379c1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0012 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018z' },
  ];

  return (
    <aside className="w-64 glass-panel border-r border-slate-200 flex flex-col h-full">
      <div className="p-6">
        <div className="mb-10 px-2 flex items-center gap-3 group cursor-default">
          <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center text-blue-400 shadow-xl group-hover:scale-110 transition-transform">
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
             </svg>
          </div>
          <span className="font-black text-xl tracking-tighter text-slate-900 uppercase">Aetheris</span>
        </div>
        
        <nav className="space-y-1.5 overflow-y-auto max-h-[60vh] custom-scrollbar pr-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all duration-300 ${
                currentView === item.id 
                  ? 'bg-white shadow-md text-blue-600 border border-slate-200 translate-x-1' 
                  : 'text-slate-500 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <svg className="w-5 h-5 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
              </svg>
              {item.label}
            </button>
          ))}
        </nav>

        <div className="mt-8 pt-8 border-t border-slate-100">
           <div className="text-[9px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-4 px-4">Experimental</div>
           <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold text-purple-500 border border-dashed border-purple-200 hover:bg-purple-50 transition-colors">
             <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse"></span>
             Sacred Geometry
           </button>
        </div>
      </div>

      <div className="mt-auto p-6 space-y-3">
        {canInstall && (
          <button 
            onClick={onInstall}
            className="w-full py-3 rounded-xl bg-slate-900 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg flex items-center justify-center gap-2"
          >
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" strokeWidth={2} /></svg>
            Deploy System
          </button>
        )}
        
        <button 
          onClick={onToggleVoice}
          className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${
            isLiveActive 
            ? 'bg-blue-500 text-white shadow-xl shadow-blue-200' 
            : 'bg-white border border-slate-200 text-slate-500 hover:border-blue-400 hover:text-blue-500'
          }`}
        >
          {isLiveActive ? (
            <>
              <div className="w-1.5 h-1.5 rounded-full bg-white animate-ping"></div>
              Neural Active
            </>
          ) : (
             <>Voice Synthesis</>
          )}
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
