
import React, { useState, useEffect } from 'react';
import { MemoryEntry } from '../types';

const BlackBoxMemory: React.FC = () => {
  const [memories, setMemories] = useState<MemoryEntry[]>([]);
  const [content, setContent] = useState('');
  const [tagsInput, setTagsInput] = useState('');
  const [search, setSearch] = useState('');
  const [isWiping, setIsWiping] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('aetheris_black_box_memory');
    if (saved) setMemories(jsonSafeParse(saved));
  }, []);

  const jsonSafeParse = (str: string) => {
    try { return JSON.parse(str); } catch { return []; }
  };

  const saveToDisk = (newMemories: MemoryEntry[]) => {
    setMemories(newMemories);
    localStorage.setItem('aetheris_black_box_memory', JSON.stringify(newMemories));
  };

  const addMemory = () => {
    if (!content.trim()) return;
    const tags = tagsInput.split(',').map(t => t.trim()).filter(t => t !== '');
    const entry: MemoryEntry = {
      id: Math.random().toString(36).substring(2, 10).toUpperCase(),
      timestamp: new Date().toISOString(),
      content: content,
      tags: tags
    };
    saveToDisk([...memories, entry]);
    setContent('');
    setTagsInput('');
  };

  const wipeMemory = () => {
    if (confirm("Are you sure you want to permanently empty the Black Box?")) {
      saveToDisk([]);
      setIsWiping(true);
      setTimeout(() => setIsWiping(false), 2000);
    }
  };

  const filteredMemories = memories.filter(m => 
    m.content.toLowerCase().includes(search.toLowerCase()) || 
    m.tags.some(t => t.toLowerCase().includes(search.toLowerCase()))
  ).reverse();

  return (
    <div className="h-full grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in zoom-in-95 duration-700">
      {/* Input Panel */}
      <div className="glass-panel rounded-3xl p-8 border border-slate-200 flex flex-col space-y-8 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl flex items-center justify-center text-blue-400 shadow-lg border border-slate-700">
            <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M21 7.5l-9-5.25L3 7.5m18 0l-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-10.5v9"/></svg>
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-800 tracking-tight">Vault Registry</h2>
            <p className="text-[10px] text-blue-500 font-black uppercase tracking-[0.2em]">Memory Pack v1.0</p>
          </div>
        </div>

        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Thought Content</label>
            <textarea 
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Inject new data into the persistent registry..."
              className="w-full h-48 p-5 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-4 focus:ring-blue-500/5 text-sm transition-all shadow-inner"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Classification Tags</label>
            <input 
              type="text"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="e.g. protocol, deploy, auth"
              className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-4 focus:ring-blue-500/5 text-sm transition-all shadow-inner"
            />
          </div>

          <div className="pt-6 grid grid-cols-2 gap-4">
            <button 
              onClick={addMemory}
              disabled={!content}
              className="py-4 bg-blue-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-blue-700 disabled:opacity-30 transition-all shadow-xl shadow-blue-200 active:scale-95"
            >
              Add Entry
            </button>
            <button 
              onClick={wipeMemory}
              className="py-4 bg-white border border-slate-200 text-red-500 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-red-50 transition-all active:scale-95"
            >
              Purge All
            </button>
          </div>
        </div>
      </div>

      {/* List Panel */}
      <div className="lg:col-span-2 glass-panel rounded-3xl border border-slate-200 flex flex-col overflow-hidden shadow-xl">
        <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-white/50">
          <div>
            <h3 className="font-black text-slate-800 uppercase text-xs tracking-widest">Registry Explorer</h3>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">{filteredMemories.length} Objects Indexed</p>
          </div>
          <div className="relative">
            <input 
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Recall by keyword or tag..."
              className="pl-12 pr-6 py-3 bg-slate-100 border-none rounded-2xl text-xs focus:outline-none focus:ring-4 focus:ring-blue-500/10 w-72 font-medium transition-all"
            />
            <svg className="w-5 h-5 text-slate-400 absolute left-4 top-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </div>

        <div className="flex-1 overflow-auto p-8 space-y-5 bg-slate-50/10 custom-scrollbar">
          {isWiping ? (
            <div className="h-full flex flex-col items-center justify-center space-y-6">
              <div className="w-20 h-20 border-8 border-slate-100 border-t-red-500 rounded-full animate-spin shadow-lg"></div>
              <p className="text-sm font-black uppercase tracking-[0.3em] text-red-500 animate-pulse">Wiping Memory Vault</p>
            </div>
          ) : filteredMemories.length > 0 ? (
            filteredMemories.map((m) => (
              <div key={m.id} className="bg-white/80 border border-slate-100 rounded-2xl p-6 shadow-sm hover:shadow-md hover:border-blue-200 transition-all group relative overflow-hidden">
                <div className="absolute top-0 right-0 w-1 h-full bg-blue-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <span className="mono text-[10px] font-black px-3 py-1 bg-slate-900 text-blue-400 rounded-lg tracking-widest shadow-lg">REG:{m.id}</span>
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{new Date(m.timestamp).toLocaleDateString()} • {new Date(m.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <div className="flex gap-2">
                    {m.tags.map((t, ti) => (
                      <span key={ti} className="text-[9px] font-black uppercase tracking-[0.1em] text-blue-500 bg-blue-50 px-3 py-1 rounded-full border border-blue-100">{t}</span>
                    ))}
                  </div>
                </div>
                <p className="text-sm text-slate-700 leading-relaxed font-medium whitespace-pre-wrap">{m.content}</p>
              </div>
            ))
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-slate-300 space-y-6">
              <div className="p-8 bg-slate-50 rounded-full border border-slate-100">
                <svg className="w-16 h-16 opacity-30" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" strokeWidth={1.5}/></svg>
              </div>
              <p className="text-xs font-black uppercase tracking-[0.3em] text-slate-400">Registry Empty</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BlackBoxMemory;
