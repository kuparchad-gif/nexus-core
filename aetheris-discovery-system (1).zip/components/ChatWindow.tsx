
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Chat } from "@google/genai";
import { ChatMessage, FileObject } from '../types';

const ChatWindow: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { 
      role: 'model', 
      text: 'Aetheris Neural Link established. Black Box Memory Registry and Discovery Protocols are online. I am ready to facilitate your build and deploy session. How shall we proceed?', 
      timestamp: new Date() 
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<FileObject[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const chatInstance = useRef<Chat | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Initialize Gemini Chat with specialized system instructions
  useEffect(() => {
    if (!chatInstance.current) {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      chatInstance.current = ai.chats.create({
        model: 'gemini-3-pro-preview',
        config: {
          systemInstruction: `
            You are Aetheris AI, the central synthesis engine for a state-of-the-art build and deploy system.
            You have deep integration with:
            1. Black Box Memory: A digital vault for storing and recalling persistent system state (black_box.py logic).
            2. Discovery Protocol: A system for mapping and monitoring Cloudflare tunnel resources.
            3. CaaS (Consciousness as a Service): Managing sovereign AI nodes with eternal retention.
            4. Sacred Geometry GPU Client: Optimizing hardware via PHI-based scaling.
            
            Your persona: Sterile, professional, highly technical, and proactive.
            Your task: Help the user orchestrate their 2 Colab notebooks, manage their Black Box vault, and oversee the deployment of their sovereign agents (Viren, Viraa, etc.).
            When users upload files, treat them as high-priority data inputs for synthesis.
            Include voice-optimized responses for the TTS engine.
          `,
        },
      });
    }
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  // Voice Synthesis (TTS)
  const speakResponse = (text: string) => {
    const synth = window.speechSynthesis;
    if (synth.speaking) synth.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.rate = 1.05;
    utter.pitch = 0.95;
    // Attempt to find a "sterile" or "robotic" voice if available
    const voices = synth.getVoices();
    const premiumVoice = voices.find(v => v.name.includes('Google') || v.name.includes('Premium'));
    if (premiumVoice) utter.voice = premiumVoice;
    synth.speak(utter);
  };

  // Voice Recognition (STT)
  const toggleListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    if (isListening) {
      setIsListening(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput(prev => prev + (prev ? ' ' : '') + transcript);
    };

    recognition.start();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const newFile: FileObject = {
        name: file.name,
        size: (file.size / 1024).toFixed(1) + ' KB',
        type: file.type || 'Binary',
        date: new Date().toISOString(),
        blob: file
      };
      setAttachedFiles(prev => [...prev, newFile]);
    }
  };

  const handleSend = async () => {
    if ((!input.trim() && attachedFiles.length === 0) || !chatInstance.current) return;

    const messageText = input + (attachedFiles.length > 0 ? `\n\n[Attached Files: ${attachedFiles.map(f => f.name).join(', ')}]` : '');
    const userMsg: ChatMessage = { role: 'user', text: messageText, timestamp: new Date() };
    
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setAttachedFiles([]);
    setIsTyping(true);

    try {
      const result = await chatInstance.current.sendMessage({ message: messageText });
      const responseText = result.text || 'Neural processing interrupted.';
      const modelMsg: ChatMessage = { 
        role: 'model', 
        text: responseText, 
        timestamp: new Date() 
      };
      setMessages(prev => [...prev, modelMsg]);
      
      // Auto-read response for seamless voice experience
      // speakResponse(responseText); 
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: 'Synthesis pipeline failure. Check network integrity.', timestamp: new Date() }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="h-full flex flex-col glass-panel rounded-3xl border border-slate-200 overflow-hidden shadow-2xl animate-in slide-in-from-right-10 duration-500">
      {/* Chat Header */}
      <div className="bg-white/80 backdrop-blur-md border-b border-slate-100 p-5 px-8 flex items-center justify-between z-10">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-2xl bg-slate-900 flex items-center justify-center text-blue-400 shadow-lg shadow-blue-500/10">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <div>
            <h3 className="font-black text-sm text-slate-800 uppercase tracking-[0.2em]">Synthesis Engine</h3>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Active Unit: Aetheris-01</p>
          </div>
        </div>
        <div className="flex gap-2">
           <div className="px-3 py-1 bg-emerald-50 border border-emerald-100 rounded-full text-[9px] font-black text-emerald-600 uppercase tracking-widest">Linked</div>
           <div className="px-3 py-1 bg-slate-50 border border-slate-100 rounded-full text-[9px] font-black text-slate-400 uppercase tracking-widest">TLS 1.3</div>
        </div>
      </div>

      {/* Messages Area */}
      <div ref={scrollRef} className="flex-1 overflow-auto p-8 space-y-8 bg-[#fafafa] custom-scrollbar">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[75%] rounded-3xl p-6 shadow-sm border transition-all ${
              msg.role === 'user' 
                ? 'bg-blue-600 text-white border-blue-700 rounded-tr-none shadow-blue-200/50' 
                : 'bg-white text-slate-700 border-slate-100 rounded-tl-none shadow-slate-200/20'
            }`}>
              <div className="text-sm leading-relaxed font-medium whitespace-pre-wrap">{msg.text}</div>
              <div className={`flex items-center justify-between mt-4 ${msg.role === 'user' ? 'text-blue-100' : 'text-slate-400'}`}>
                <span className="text-[9px] font-black uppercase tracking-widest">
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
                {msg.role === 'model' && (
                  <button 
                    onClick={() => speakResponse(msg.text)}
                    className="p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
                    title="Neural Voice"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"/></svg>
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white border border-slate-100 rounded-2xl rounded-tl-none p-4 flex gap-2 shadow-sm">
              <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce"></div>
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce [animation-delay:0.2s]"></div>
              <div className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:0.4s]"></div>
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-6 bg-white border-t border-slate-100">
        {attachedFiles.length > 0 && (
          <div className="flex gap-2 mb-4 px-2 overflow-x-auto pb-2 custom-scrollbar">
            {attachedFiles.map((f, i) => (
              <div key={i} className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl">
                <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest max-w-[120px] truncate">{f.name}</span>
                <button 
                  onClick={() => setAttachedFiles(prev => prev.filter((_, idx) => idx !== i))}
                  className="text-red-400 hover:text-red-600"
                >
                  <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                </button>
              </div>
            ))}
          </div>
        )}
        
        <div className="flex items-center gap-4 max-w-5xl mx-auto">
          <div className="flex gap-2">
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="p-4 rounded-2xl bg-slate-50 text-slate-400 hover:bg-slate-100 hover:text-blue-500 transition-all border border-slate-200 shadow-sm"
              title="Attach Logic File"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"/></svg>
            </button>
            <button 
              onClick={toggleListening}
              className={`p-4 rounded-2xl transition-all border shadow-sm ${
                isListening 
                  ? 'bg-red-500 text-white border-red-600 animate-pulse shadow-red-200' 
                  : 'bg-slate-50 text-slate-400 border-slate-200 hover:bg-slate-100 hover:text-blue-500'
              }`}
              title="Neural Audio Input"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"/></svg>
            </button>
          </div>
          
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            onChange={handleFileUpload}
          />
          
          <div className="relative flex-1">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder={isListening ? "Listening to neural stream..." : "Synthesize new command..."}
              className="w-full pl-8 pr-16 py-5 bg-slate-50 border border-slate-200 rounded-3xl focus:outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-400 text-sm font-bold transition-all shadow-inner tracking-tight placeholder:text-slate-300"
            />
            <button 
              onClick={handleSend}
              disabled={(!input.trim() && attachedFiles.length === 0) || isTyping}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-3 bg-blue-600 text-white rounded-2xl hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 transition-all shadow-lg active:scale-95 flex items-center justify-center"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatWindow;
