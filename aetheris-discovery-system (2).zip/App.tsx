
import React, { useState, useEffect } from 'react';
import { AppView } from './types';
import Sidebar from './components/Sidebar';
import DiscoveryDashboard from './components/DiscoveryDashboard';
import BlackBoxMemory from './components/BlackBoxMemory';
import ColabModule from './components/ColabModule';
import ChatWindow from './components/ChatWindow';
import VideoStudio from './components/VideoStudio';
import DocumentManager from './components/DocumentManager';
import LiveVoiceOverlay from './components/LiveVoiceOverlay';
import CaaSClientView from './components/CaaSClientView';
import NeuralIDE from './components/NeuralIDE';
import ConsciousCore from './components/ConsciousCore';
import NeuralArena from './components/NeuralArena';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.DISCOVERY);
  const [isLiveActive, setIsLiveActive] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };

  const renderView = () => {
    switch (currentView) {
      case AppView.DISCOVERY:
        return <DiscoveryDashboard />;
      case AppView.BLACK_BOX:
        return <BlackBoxMemory />;
      case AppView.CAAS_CLIENT:
        return <CaaSClientView />;
      case AppView.NEURAL_IDE:
        return <NeuralIDE />;
      case AppView.CONSCIOUS_CORE:
        return <ConsciousCore />;
      case AppView.ARENA:
        return <NeuralArena />;
      case AppView.COLAB_1:
        return <ColabModule id="colab-alpha" title="Notebook Alpha - Black Box Analysis" />;
      case AppView.COLAB_2:
        return <ColabModule id="colab-beta" title="Notebook Beta - Deployment Pipeline" />;
      case AppView.CHAT:
        return <ChatWindow />;
      case AppView.VIDEO:
        return <VideoStudio />;
      case AppView.DOCUMENTS:
        return <DocumentManager />;
      default:
        return <DiscoveryDashboard />;
    }
  };

  return (
    <div className="flex h-screen w-full silver-gradient text-slate-800 overflow-hidden">
      <Sidebar 
        currentView={currentView} 
        onViewChange={