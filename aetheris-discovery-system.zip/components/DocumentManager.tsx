
import React from 'react';

const DocumentManager: React.FC = () => {
  const docs = [
    { name: 'Black_Box_Architecture.pdf', size: '2.4 MB', type: 'Technical Doc', date: '2024-05-12' },
    { name: 'Discovery_Protocol_Specs.v3', size: '842 KB', type: 'Protocol Spec', date: '2024-05-14' },
    { name: 'Deploy_Pipeline_Alpha.yml', size: '12 KB', type: 'Configuration', date: '2024-05-15' },
    { name: 'Security_Audit_Report.docx', size: '4.1 MB', type: 'Report', date: '2024-05-10' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-top-4 duration-500">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass-panel rounded-2xl p-8 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl font-bold text-slate-800">Knowledge Repository</h2>
            <button className="text-xs font-bold bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors uppercase tracking-widest">Upload Resource</button>
          </div>
          
          <div className="space-y-3">
            {docs.map((doc, idx) => (
              <div key={idx} className="flex items-center justify-between p-4 rounded-xl border border-slate-100 hover:border-blue-200 hover:bg-blue-50/30 transition-all group cursor-pointer">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded bg-slate-100 flex items-center justify-center text-slate-400 group-hover:bg-blue-100 group-hover:text-blue-500 transition-colors">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-slate-700">{doc.name}</h4>
                    <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">{doc.type} • {doc.size}</p>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Last Modified</div>
                    <div className="text-xs text-slate-600 font-medium">{doc.date}</div>
                  </div>
                  <button className="text-slate-300 hover:text-blue-500">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 6.75a.75.75 0 110-1.5.75.75 0 010 1.5zM12 12.75a.75.75 0 110-1.5.75.75 0 010 1.5zM12 18.75a.75.75 0 110-1.5.75.75 0 010 1.5z"/></svg>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-panel rounded-2xl p-8 border border-slate-200 flex flex-col shadow-sm">
          <h2 className="text-lg font-bold text-slate-800 mb-6">3D Infrastructure View</h2>
          <div className="flex-1 bg-slate-50 border border-slate-100 rounded-2xl flex flex-col items-center justify-center relative group overflow-hidden">
            {/* Visual simulation of 3D UI */}
            <div className="absolute inset-0 opacity-10 pointer-events-none">
              <svg className="w-full h-full" viewBox="0 0 100 100">
                <defs><pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse"><path d="M 10 0 L 0 0 0 10" fill="none" stroke="currentColor" strokeWidth="0.5"/></pattern></defs>
                <rect width="100%" height="100%" fill="url(#grid)" />
              </svg>
            </div>
            
            <div className="relative z-10 text-center px-8">
              <div className="w-24 h-24 mx-auto mb-6 relative">
                <div className="absolute inset-0 bg-blue-500/20 rounded-xl rotate-45 animate-[spin_10s_linear_infinite]"></div>
                <div className="absolute inset-2 bg-purple-500/20 rounded-xl -rotate-12 animate-[spin_15s_linear_infinite]"></div>
                <div className="absolute inset-4 glass-panel border border-slate-200 rounded-lg flex items-center justify-center">
                  <svg className="w-8 h-8 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 7.5l-9-5.25L3 7.5m18 0l-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-10.5v9" />
                  </svg>
                </div>
              </div>
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-widest mb-2">Topology Scan</h3>
              <p className="text-[10px] text-slate-400 font-medium">Render engine initializing. Hardware acceleration detected.</p>
              <button className="mt-6 px-4 py-2 border border-slate-200 rounded-lg text-[10px] font-bold uppercase tracking-widest text-slate-500 hover:bg-white hover:text-blue-500 transition-all">Launch Perspective</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentManager;
