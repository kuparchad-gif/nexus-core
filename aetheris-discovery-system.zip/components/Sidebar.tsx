
import React from 'react';
import { AppView } from '../types';

interface SidebarProps {
  currentView: AppView;
  onViewChange: (view: AppView) => void;
  onToggleVoice: () => void;
  isLiveActive: boolean;
  onInstall: () => void;
  canInstall: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onViewChange, onToggleVoice, isLiveActive, onInstall, canInstall }) => {
  const menuItems = [
    { id: AppView.DISCOVERY, label: 'Discovery', icon: 'M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
    { id: AppView.BLACK_BOX, label: 'Vault Registry', icon: 'M21 7.5l-9-5.25L3 7.5m18 0l-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-10.5v9' },
    { id: AppView.COLAB_1, label: 'Logic Node A', icon: 'M17.25 6.75L22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3l-4.5 16.5' },
    { id: AppView.COLAB_2, label: 'Logic Node B', icon: 'M17.25 6.75L22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3l-4.5 16.5' },
    { id: AppView.CHAT, label: 'Synthesis AI', icon: 'M7.5 8.25h9m-9 3H12m-9.75 1.51c0 1.6 1.123 2.994 2.707 3.227 1.129.166 2.27.293 3.423.379.35.026.67.21.865.501L12 21l2.755-4.133a1.14 1.14 0 01.865-.501 48.172 48.172 0 003.423-.379c1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0012 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018z' },
    { id: AppView.VIDEO, label: 'Veo Visuals', icon: 'M15.75 10.5l4.72-4.72a.75.75 0 011.28.53v11.38a.75.75 0 01-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 002.25-2.25v-9a2.25 2.25 0 00-2.25-2.25h-9A2.25 2.25 0 002.25 7.5v9a2.25 2.25 0 002.25 2.25z' },
  ];

  return (
    <aside className="w-64 glass-panel border-r border-slate-200 flex flex-col h-full">
      <div className="p-6">
        <div className="mb-10 px-2 flex items-center gap-3 group cursor-default">
          <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center text-blue-400 shadow-xl group-hover:scale-110 transition-transform">
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
             </svg>
          </div>
          <span className="font-black text-xl tracking-tighter text-slate-900 uppercase">Aetheris</span>
        </div>
        
        <nav className="space-y-1.5">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-300 ${
                currentView === item.id 
                  ? 'bg-white shadow-md text-blue-600 border border-slate-200 translate-x-1' 
                  : 'text-slate-500 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <svg className="w-5 h-5 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
              </svg>
              {item.label}
            </button>
          ))}
        </nav>

        <div className="mt-8 pt-8 border-t border-slate-100">
           <div className="text-[9px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-4 px-4">Experimental</div>
           <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold text-purple-400 border border-dashed border-purple-200 hover:bg-purple-50 transition-colors opacity-60">
             <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse"></span>
             Deep Protocol 
           </button>
        </div>
      </div>

      <div className="mt-auto p-6 space-y-3">
        {canInstall && (
          <button 
            onClick={onInstall}
            className="w-full py-3 rounded-xl bg-slate-900 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg flex items-center justify-center gap-2"
          >
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" strokeWidth={2} /></svg>
            Deploy to System
          </button>
        )}
        
        <button 
          onClick={onToggleVoice}
          className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${
            isLiveActive 
            ? 'bg-blue-500 text-white shadow-xl shadow-blue-200' 
            : 'bg-white border border-slate-200 text-slate-500 hover:border-blue-400 hover:text-blue-500'
          }`}
        >
          {isLiveActive ? (
            <>
              <div className="w-1.5 h-1.5 rounded-full bg-white animate-ping"></div>
              Neural Link Hot
            </>
          ) : (
             <>Voice Synthesis</>
          )}
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
