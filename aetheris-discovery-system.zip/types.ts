
export enum AppView {
  DISCOVERY = 'discovery',
  BLACK_BOX = 'black_box',
  COLAB_1 = 'colab_1',
  COLAB_2 = 'colab_2',
  CHAT = 'chat',
  VIDEO = 'video',
  DOCUMENTS = 'documents'
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface DiscoveryResource {
  id: string;
  name: string;
  type: string;
  status: 'active' | 'idle' | 'processing';
  lastSeen: string;
}

export interface MemoryEntry {
  id: string;
  timestamp: string;
  content: string;
  tags: string[];
}
